import { createSlice } from "@reduxjs/toolkit";
 
const bookSlice=createSlice({
 
name:'book',
 
initialState:{
java:80,
dsa:20
 
},
reducers:
{
returnBookdsa:(state)=>
{
    state.dsa+=1
},
issueBookdsa:(state)=>
{
    state.dsa-=1
},

returnBookjava:(state)=>
{
    state.java+=1
},
issueBookjava:(state)=>
{
    state.java-=1
},
returnBookdsaN:(state,action)=>
{
    state.dsa+=action.payload
},
 
issueBookdsaN:(state,action)=>
{
    state.dsa-=action.payload
},
returnBookjavaN:(state,action)=>
{
    state.java+=action.payload
},
 
issueBookjavaN:(state,action)=>
{
    state.java-=action.payload
}

}
 
})
 
export const {returnBookdsa,issueBookdsa, returnBookjava,issueBookjava, returnBookdsaN, issueBookdsaN, returnBookjavaN, issueBookjavaN}=bookSlice.actions
export default  bookSlice.reducer;