import { useDispatch, useSelector } from "react-redux"
import { issueBookdsa, issueBookdsaN, returnBookdsa } from "./BookSlice"
import { issueBookjava, returnBookjava } from "./BookSlice"
import { useState } from "react"
 
const App=()=>
{
    let[Qdsa,setQdsa]=useState()

  const {dsa,java}= useSelector((state)=>state.book)
  const dispatch=useDispatch()
 
    return(<>
   
    <input type="number" placeholder="enter no of book " onChange={(e)=>setQdsa(e.target.value)}/>

    <h1> Java Book {java}</h1>
    <h1> DSA Book {dsa}</h1>

    <button onClick={()=>dispatch(issueBookdsa())}>Issue book DSA</button>
    <button onClick={()=>dispatch(returnBookdsa())}>return book DSA</button>
    <button onClick={()=>dispatch(issueBookjava())}>Issue book Java</button>
    <button onClick={()=>dispatch(returnBookjava())}>return book Java</button>

    <button onClick={()=>dispatch(issueBookdsaN(Qdsa))}> Issue Book  DSA  N </button>
   
    </>)
}
 
export default App;