import Billing from "./components/Billing";
import FlowerList from "./components/FlowerList";
import WatchList from "./components/WatchList";

const App2 = () => {
  return (
    <>
      <h1>Product Store</h1>
      <FlowerList />
      <WatchList />
      <Billing />
    </>
  );
};

export default App2;