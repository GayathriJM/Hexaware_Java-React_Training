import { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { issueBookdsa, issueBookdsaN, issueBookjava, issueBookjavaN, returnBookdsa, returnBookdsaN, returnBookjava, returnBookjavaN } from "./BookSlice"

const Admin = () => {
    let [Qdsa, setQdsa] = useState()
    let [Qjava, setQjava] = useState()

    const { dsa, java } = useSelector((state) => state.book)
    const dispatch = useDispatch()

    return (
        <>
            <h2>Admin dashboard</h2>

            <input type="number" placeholder="DSA books qty" onChange={(e) => setQdsa(Number(e.target.value))} />
            <input type="number" placeholder="Java books qty" onChange={(e) => setQjava(Number(e.target.value))} />

            <h1>Java Book{java}</h1>
            <h1>DSA Book{dsa}</h1>

            <button onClick={() => dispatch(issueBookdsa())}>Issue DSA Book</button>
            <button onClick={() => dispatch(returnBookdsa())}>Return DSA Book</button>
            <button onClick={() => dispatch(issueBookjava())}>Issue Java Book</button>
            <button onClick={() => dispatch(returnBookjava())}>Return Java Book</button>

            <button onClick={() => dispatch(issueBookdsaN(Qdsa))}>Issue DSA Books N</button>
            <button onClick={() => dispatch(returnBookdsaN(Qdsa))}>Return DSA Books N</button>
            <button onClick={() => dispatch(issueBookjavaN(Qjava))}>Issue Java Books N</button>
            <button onClick={() => dispatch(returnBookjavaN(Qjava))}>Return Java Books N</button>
        </>
    )
}

export default Admin;