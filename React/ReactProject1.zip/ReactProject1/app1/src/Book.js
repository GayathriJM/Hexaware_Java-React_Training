import "./App.css"
//This is a functional component called Book
//It takes props (data from parent) like name, price, qty, city, pic
const Book=({name,price,qty,city,pic})=>{


    //props - way to take info(value) from one component to other component
    //App(parent)  Book(child) - how to send data from parent to child

    return (<>
    
    <div className="cont">
    <h1>Name: {name}</h1>
    <h2>Price: {price}</h2>
    <h2>Qty: {qty}</h2>
    <img src={pic}/>
    <h2>City: {city}</h2>
    </div>
    </>)
}
export default Book;