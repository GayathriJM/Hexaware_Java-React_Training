import "./App.css"
const Productdetails=({id,title,image,price,description,brand,model,color,category,discount})=>{


    return (<>
    
    <div className="cont">
    <h1>productId: {id}</h1>
    <h2>Title: {title}</h2>
    <img src={image}/>
    <h2>Price: {price}</h2>
    <h2>Description: {description}</h2>
    <h2>Brand: {brand}</h2>
    <h2>Model: {model}</h2>
    <h2>Color: {color}</h2>
    <h2>Category: {category}</h2>
    <h2>Discount: {discount}</h2>

    </div>
    </>)
}
export default Productdetails;