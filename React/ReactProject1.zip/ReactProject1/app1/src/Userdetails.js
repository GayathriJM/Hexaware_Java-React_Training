import "./App.css"
const Userdetails=({id,title,body})=>{


    return (<>
    
    <div className="cont">
    <h1>userId: {id}</h1>
    <h2>Title: {title}</h2>
    <h2>Body: {body}</h2>
    </div>
    </>)
}
export default Userdetails;