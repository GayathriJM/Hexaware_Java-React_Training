import "./App.css"
const Food =({name,price,qty,hotel,pic})=>{
    return(<>
    <div className="cont">
        <h1>Food: {name}</h1>
        <h2>Price: {price}</h2>
        <h2>Qty: {qty}</h2>
        <img src={pic}/>
        <h2>Hotel: {hotel}</h2>

    </div>
    
    </>)
}
export default Food;