import { useEffect, useState } from "react"
import Productdetails from "./Productdetails"
const Apiex2=()=>
{

    let  [posts,setPost]=useState([])
     useEffect(()=>
        {
               
      fetch("https://fakestoreapi.in/api/products")
      .then((res)=> res.json()).
      then((temp)=>setPost(temp.products))
      .catch((e)=>console.log(e))
 
        },[])
 
    return(<> 
       
    {
       
       posts.map((temp)=> <Productdetails id={temp.id} title={temp.title} image={temp.image} price={temp.price} description={temp.description} brand={temp.brand} model={temp.model} color={temp.color} category={temp.category} discount={temp.discount}/>)
    }
 
    </>)
}
 
export default Apiex2