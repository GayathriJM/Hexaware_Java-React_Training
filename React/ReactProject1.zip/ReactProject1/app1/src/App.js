import Book from "./Book";
import Food from "./Food";

const App=()=>
{

  let name="Gayathri"
  let age=21;

      return(<>
       <h1> Welcome in React</h1>
       <h2>Name : {name}</h2>
       <h2>Age : {age}</h2>

       <Book name="react" price="300" qty="20" city="Delhi" pic="../logo192.png"/><br></br>
       <Book name="nodejs" price="600" qty="40" city="Pune"/><br></br>
       <Book name="springboot" price="900" qty="60" city="Mumbai"/><br></br>

       <Food name="Pizza" price="250" qty="2" hotel="Dominos" pic="../pizza.jpg"/>

      </>)
 
}
export default App;