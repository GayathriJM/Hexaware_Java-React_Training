import { useState } from "react"
import "./App.css"
const Userinfo=()=>
{
 
 
    let [name,setName]=useState()
    let [age,setAge]=useState()
    let [department,setDepartment]=useState()
    let [salary,setSalary]=useState()
 
 
 
 
  const handleName=(e)=>
  {
   setName(e.target.value)
  }
 
 
 
  const handleAge=(e)=>
  {
   setAge(e.target.value)
  }

  const handleDepartment=(e)=>
  {
   setDepartment(e.target.value)
  }

  const handleSalary=(e)=>
  {
   setSalary(e.target.value)
  }
     
    return (<div className="cont">
 
 
    <input type="text" placeholder="Enter ur name" onChange={handleName}/>
    <input type="text" placeholder="Enter ur Age" onChange={handleAge}/>
    <input type="text" placeholder="Enter ur department" onChange={handleDepartment}/>
    <input type="text" placeholder="Enter ur salary" onChange={handleSalary}/>
 
      <h2>Name {name}</h2>
      <h2>Age {age}</h2>
      <h2>Department {department}</h2>
      <h2>Salary {salary}</h2>
   
    </div>)
}
export default Userinfo