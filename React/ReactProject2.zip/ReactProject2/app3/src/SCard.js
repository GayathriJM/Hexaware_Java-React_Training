import React from 'react'
import { Button } from 'semantic-ui-react'
import {
  CardMeta,
  CardHeader,
  CardDescription,
  CardContent,
  Card,
  Icon,
  Image,
} from 'semantic-ui-react'
 
const SCard = ({id,title,thumbnail,category,RemoveData,UpdateCategory}) => (
  <Card>
    <Image src={thumbnail} wrapped ui={false} />
    <CardContent>
      <CardHeader>{id}</CardHeader>
      <CardDescription>
        {title}
      </CardDescription>
    </CardContent>
    <CardContent extra>
      <a>
        <Icon name='user' />
        category
      </a>
    </CardContent>

    <Button inverted color='purple' onClick={()=>RemoveData(id)}> Remove</Button>
    <Button inverted color='blue' onClick={() => UpdateCategory(id)}> Edit </Button>


  </Card>
)
 
export default SCard
 