import React,{ useState } from "react";
import "./App.css"
import {
  CardMeta,
  CardHeader,
  CardDescription,
  CardContent,
  Card,
  Icon,
  Button,
  Image,
} from 'semantic-ui-react'

const PCard=({id,title,thumbnail,category,RemoveData,UpdateCategory})=>
{

    const [newCategory, setNewCategory] = useState("");
 
    return(<div className="content">
   
     <h1> {id}</h1>
     <h2>{title}</h2>
     <img src={thumbnail}/>
     <input type="text" placeholder="enter category" onChange={(e) => setNewCategory(e.target.value)}/>
     <h2> {category}</h2>
     <button onClick={()=>RemoveData(id)}> Remove</button>
     <button onClick={() => UpdateCategory(id, newCategory)}> update category</button>
 
    </div>)
}
 
export default PCard;