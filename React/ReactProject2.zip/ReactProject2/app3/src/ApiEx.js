import React,{ useEffect, useState } from "react"
import PCard from "./PCard"

import { Dimmer, Loader, Image, Segment } from 'semantic-ui-react'
import {
  ModalHeader,
  ModalDescription,
  ModalContent,
  ModalActions,
  Button,
  Header,
  Modal,
} from 'semantic-ui-react'
import SCard from "./SCard"

 
const ApiEX=()=>
{
 
    let [Products,setProducts]=useState([])
    let [FProducts,setFProducts]=useState([])
    let [flag,setFlag]=useState(false)
    let [search, setSearch]=useState("")

    let [title, setTitle] = useState("");
    let [category, setCategory] = useState("");
    let [thumbnail, setThumbnail] = useState("");

    const [editId, setEditId] = useState(null);
const [newCategory, setNewCategory] = useState("");

    const addProduct = () => {
        let data = {
            id: Products.length+1, 
            title: title,
            category: category,
            thumbnail: thumbnail
        };
        setProducts([...Products, data]);
    }

    const handleSearch=(e)=>{
        setSearch(e.target.value)
    }

    const RemoveData=(id)=>{
        setProducts(Products.filter((temp)=>temp.id!=id))
    }

    // const UpdateCategory=(id, newCategory)=>{
    //    let data = Products.map((temp)=>temp.id===id ? {...temp, category : newCategory} : temp)
    //    setProducts(data);
    // }

    const handleEditClick = (id) => {
  const p = Products.find(p => p.id === id);
  setNewCategory(p.category);
  setEditId(id);
};

const UpdateCategory = (id, newCat) => {
  setProducts(Products.map(p =>
    p.id === id ? { ...p, category: newCat } : p
  ));
};


    
 
    useEffect(()=>
        {
       
              fetch("https://dummyjson.com/products")
              .then((res)=>res.json())
              .then((temp)=>{
                setProducts(temp.products)
                setFlag(true)
        })
              .catch((e)=>console.log(e))
 
 
        } ,[])

        useEffect(()=>{
            let data = Products.filter((temp)=>temp.category.includes(search))
            setFProducts(data)
        }, [search])

 
    return(<>

    {editId !== null && (
  <Modal open onClose={() => setEditId(null)}>
    <Modal.Header>Edit Category</Modal.Header>
    <Modal.Content>
      <input
        type="text"
        placeholder="New category"
        value={newCategory}
        onChange={(e) => setNewCategory(e.target.value)}
      />
    </Modal.Content>
    <Modal.Actions>
      <Button color="green" onClick={() => {
        UpdateCategory(editId, newCategory);
        setEditId(null);
        setNewCategory("");
      }}>Update</Button>
      <Button color="red" onClick={() => setEditId(null)}>Cancel</Button>
    </Modal.Actions>
  </Modal>
)}



    <input type="text" placeholder="search by category" onChange={handleSearch}/>

    <input type="text" placeholder="enter title" onChange={(e) => setTitle(e.target.value)} />
    <input type="text" placeholder="enter category" onChange={(e) => setCategory(e.target.value)} />
    <input type="text" placeholder="enter image url" onChange={(e) => setThumbnail(e.target.value)} />
    <button onClick={addProduct}>add new item</button>

 
 
 
 {

//     search.length?
//     FProducts.map((temp)=><SCard id={temp.id} title={temp.title} category={temp.category} thumbnail={temp.thumbnail} RemoveData={RemoveData}  UpdateCategory={UpdateCategory}/> )
// :

flag?
   Products.map((temp)=><SCard id={temp.id} title={temp.title} category={temp.category} thumbnail={temp.thumbnail} RemoveData={RemoveData}  UpdateCategory={() => handleEditClick(temp.id)}/> )
 :

  <div>
    <Segment>
      <Dimmer active>
        <Loader>Loading</Loader>
      </Dimmer>

      <Image src='/images/wireframe/short-paragraph.png' />
    </Segment>
</div>
   
 }


   
   
    </>)
}
export default ApiEX
 
 
// useEffect (()=> , [])
// useEffect(()=> ,[a])    