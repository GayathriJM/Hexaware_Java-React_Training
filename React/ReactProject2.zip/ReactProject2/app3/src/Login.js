import { useState } from "react"
 
const Login=()=>
{
 
 //state variable
let [Id,setId]=useState()
let [pass,setPass]=useState()
let [newPass,setNewPass]=useState()
 
 
 
  const handleUserId=(event)=>
  {
  setId(event.target.value)
  }
 
 
  const handleUserPass=(event)=>
  {
  setPass(event.target.value)
  }

  const handleNewPass=(event)=>
  {
  setNewPass(event.target.value)
  }

  const signUp=()=>{
    localStorage.setItem(Id,pass)
  }

   const signIn=()=>{
    let p = localStorage.getItem(Id);
    if(p==pass){
        alert("Welcome")
    }
    else{
        alert("Try again")
    }
  }

  const updatePassword=()=>{
    let p = localStorage.getItem(Id);
    if(p==pass){
        localStorage.setItem(Id, newPass)
        alert("password updated")
    }
    else{
        alert("incorrect password")
    }
  }


 
return(<>
 
 
<div className="cont">
<input type="text" placeholder="enter user id " onChange={handleUserId}/>
<input type="password" placeholder="enter Password " onChange={handleUserPass}/>

<input type="password" placeholder="enter password " onChange={handleNewPass}/>

 
<button onClick={signIn}> Sign In</button>
<button onClick={signUp}> Sign up</button>
<button onClick={updatePassword}> Update password</button>
 
 
</div>
 
 
</>)
 
 
}
export default Login