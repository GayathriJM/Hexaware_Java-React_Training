import Routes1 from './Routes1';

const App=()=>{

  return(<>
    
    <Routes1 />
    
  
  </>)
}

export default App;
