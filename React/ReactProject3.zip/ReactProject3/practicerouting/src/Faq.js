const Faq=()=>{

    return(<>

    <h1>FAQ</h1>
    <h2>what is name of your company</h2>
    <h2>My company name is hexaware</h2>
    
    </>)
}
export default Faq