import { useParams } from "react-router-dom";

const ShowE = () => {
  let { itemCode, name, price, quantity, city }=useParams();

  return (
    <>
      <h1>{itemCode}</h1>
      <h2>{name}</h2>
      <h2>{price}</h2>
      <h2>{quantity}</h2>
      <h2>{city}</h2>
    </>
  );
};

export default ShowE;
