import logo from './logo.svg';
import './App.css';
import { Link, Route, Routes } from 'react-router-dom';
import Contact from './Contact';
import Home from './Home';
import Faq from './Faq';
import Login from './Login';
import Welcome from './Welcome';
import PayslipCalculator from './PayslipCalculator';
import ShowPayslip from './ShowPayslip';
import UCard from './UCard';
import ShowU from './ShowU';
import UCardDisplay from './UCardDisplay';
import ECardDisplay from './ECardDisplay';
import ShowE from './ShowE';
import Protected from './Protected';

function App() {


 

  return (

    
    <div className='cont'>

      <table border="2">
        <tr>
          <Link to="/"><td>Home</td></Link>
          <Link to="/Faq"><td>Faq</td></Link>
          <Link to="/Contact"><td>Contact</td></Link>
          <Link to="/login"><td>Login</td></Link>
          <Link to="/payslip"><td>Payslip</td></Link>
          <Link to="/ucardlist"><td>Users</td></Link>
          <Link to="/ecardlist"><td>Electronics</td></Link>

        </tr>
      </table>

      <Routes>
        <Route path= "/" element={<Home/>}/>
        <Route path= "/contact" element={<Contact/>}/>
        <Route path="/faq" element={<Protected Component={Faq} />} />
        <Route path= "/login" element={<Login/>}/>
        <Route path= "/welcome" element={<Welcome/>}/>
        <Route path= "/payslip" element={<PayslipCalculator/>}/>
        <Route path= "/showpayslip" element={<ShowPayslip/>}/>
        <Route path="/ucardlist" element={<UCardDisplay/>} />
        <Route path= "/ucard/:UserId/:Name/:Salary" element={<ShowU/>}/>
        <Route path="/ecardlist" element={<ECardDisplay />} />
        <Route path="/ecard/:itemCode/:name/:price/:quantity/:city" element={<ShowE />} />
      </Routes>

    </div>
  );
}

export default App;
