package com.hexaware.service;

import com.hexaware.dto.AddressDTO;
import com.hexaware.entity.Order;
import com.hexaware.enums.PaymentMethod;

public interface EmailService {
	void sendOrderConfirmation(String to, Order order, AddressDTO address, PaymentMethod paymentMethod);
}

