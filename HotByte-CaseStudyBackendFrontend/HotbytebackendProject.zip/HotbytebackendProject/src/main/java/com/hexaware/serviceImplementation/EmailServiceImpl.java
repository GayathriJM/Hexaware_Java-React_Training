package com.hexaware.serviceImplementation;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.hexaware.dto.AddressDTO;
import com.hexaware.entity.Order;
import com.hexaware.enums.PaymentMethod;
import com.hexaware.service.EmailService;

@Service
public class EmailServiceImpl implements EmailService {

	 @Autowired
	    private JavaMailSender mailSender;

	    public void sendOrderConfirmation(String to, Order order, AddressDTO address, PaymentMethod paymentMethod) {
	        SimpleMailMessage message = new SimpleMailMessage();
	        message.setTo(to);
	        message.setSubject("Order Confirmation - Order #" + order.getOrderId());
	        message.setText("Thank you for your order!\n\n"
	                + "Order ID: " + order.getOrderId() + "\n"
	                + "Total: ₹" + order.getTotalPrice() + "\n"
	                + "Payment Method: " + paymentMethod + "\n"
	                + "Delivery Address: " + address.getStreet() + ", " 
	                + address.getCity() + ", " 
	                + address.getState() + " - " 
	                + address.getPincode() + "\n\n"
	                + "We’ll notify you when it's out for delivery.");

	        mailSender.send(message);
	    }

}
