import React from 'react';
import { Image } from 'primereact/image';
import { Button } from 'primereact/button';
import { Link } from 'react-router-dom';

export default function Footer() {
    return (
        <footer style={{
            backgroundColor: '#f1f1f1',
            color: '#333',
            padding: '50px 20px 30px 20px',
        
        }}>
            <div style={{
                maxWidth: '1200px',
                margin: '0 auto',
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                alignItems: 'flex-start'
            }}>

                {/* Logo */}
                <div style={{
                    flex: '1 1 220px',
                    marginBottom: '20px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start', 
                }}>
                    <Image
                        src="/hotbytelogo.png"
                        alt="HotByte Logo"
                        width="200"
                        style={{ marginBottom: '10px' }}
                    />
                    <p style={{
                        margin: 0,
                        fontSize: '0.95rem',
                        lineHeight: '1.4',
                        color: 'grey',
                        maxWidth: '250px'
                    }}>
                        Your favorite food ordering platform. Fresh, fast, and delicious meals delivered right to your doorstep.
                    </p>
                </div>

                {/* Quick Links */}
                <div style={{
                    flex: '1 1 150px',
                    marginBottom: '20px',
                    textAlign: 'left' 
                }}>
                    <h4 style={{ marginBottom: '10px' }}>Quick Links</h4>
                    <ul style={{ listStyle: 'none', padding: 0, lineHeight: '1.8' }}>
                        <li><Link to={"./"} style={{ color: '#333', textDecoration: 'none' }}>Home</Link></li>
                        <li><Link to={"./menu"} style={{ color: '#333', textDecoration: 'none' }}>Menu</Link></li>
                        <li><Link to={"./about"} style={{ color: '#333', textDecoration: 'none' }}>About</Link></li>
                        <li><Link to={"/contact"} style={{ color: '#333', textDecoration: 'none' }}>Contact</Link></li>
                    </ul>
                </div>

                {/* Support */}
                <div style={{
                    flex: '1 1 150px',
                    marginBottom: '20px',
                    textAlign: 'left' 
                }}>
                    <h4 style={{ marginBottom: '10px' }}>Support</h4>
                    <ul style={{ listStyle: 'none', padding: 0, lineHeight: '1.8' }}>
                        <li><a href="#" style={{ color: '#333', textDecoration: 'none' }}>Help Center</a></li>
                        <li><Link to={"/contact"} style={{ color: '#333', textDecoration: 'none' }}>Contact Us</Link></li>
                        <li><Link to={"./terms"} style={{ color: '#333', textDecoration: 'none' }}>Terms of Service</Link></li>
                    </ul>
                </div>

                {/* Contact */}
                <div style={{
                    flex: '1 1 200px',
                    marginBottom: '20px',
                    textAlign: 'left' 
                }}>
                    <h4 style={{ marginBottom: '10px' }}>Contact</h4>
                    <ul style={{ listStyle: 'none', padding: 0, lineHeight: '1.8', fontSize: '0.95rem' }}>
                        <li><i className="pi pi-envelope" style={{ color: '#ff2442'}}></i> support@hotbyte.com</li>
                        <li><i className="pi pi-phone" style={{ color: '#ff2442' }}></i> (555) 123-4567</li>
                        <li><i className="pi pi-map-marker" style={{ color: '#ff2442' }}></i>  123 Food Street, City</li>
                    </ul>
                </div>
            </div>

            {/* Social Media Icons */}
            <div style={{
                marginTop: '30px',
                display: 'flex',
                justifyContent: 'center',
                gap: '15px',
                
            }}>
                <Button icon="pi pi-facebook" className="p-button-rounded p-button-text" style={{ color: '#333' }} />
                <Button icon="pi pi-instagram" className="p-button-rounded p-button-text" style={{ color: '#333' }} />
                <Button icon="pi pi-twitter" className="p-button-rounded p-button-text" style={{ color: '#333' }} />
                <Button icon="pi pi-github" className="p-button-rounded p-button-text" style={{ color: '#333' }} />
                <Button icon="pi pi-globe" className="p-button-rounded p-button-text" style={{ color: '#333' }} />
            </div>

            <div style={{ marginTop: '20px', fontSize: '0.85rem', color: '#333', textAlign: 'center' }}>
                © 2025 HotByte. All rights reserved.
            </div>
        </footer>
    );
}
