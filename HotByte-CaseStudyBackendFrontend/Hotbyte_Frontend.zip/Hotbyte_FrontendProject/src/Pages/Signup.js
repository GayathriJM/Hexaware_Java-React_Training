import React from 'react';
import CustomMenubar from '../Components/CustomMenubar';
import SignUpUser from '../Components/SignUpUser';
import Footer from '../Components/Footer';



const Signup = () => {
  return (
    <>
    <CustomMenubar />
    <SignUpUser/>
    <Footer/>

    </>
  );
};
export default Signup;