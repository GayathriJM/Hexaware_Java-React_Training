import React from 'react';
import ContactUser from '../Components/ContactUser'; 
import CustomMenubar from '../Components/CustomMenubar'; 
import { Link } from 'react-router-dom'; 
const Contact = () => {
    return (
        <>
            <CustomMenubar />
            
            <ContactUser />

        </>
    );
}
export default Contact;