import React from 'react';
import AdminLayout from '../../Components/Admin/AdminLayout';
import MenuManagement from '../../Components/Admin/MenuManagement';


export default function MenuItemsPage() {
  return (
    <AdminLayout>
      <MenuManagement /> 
    </AdminLayout>
  );
}
