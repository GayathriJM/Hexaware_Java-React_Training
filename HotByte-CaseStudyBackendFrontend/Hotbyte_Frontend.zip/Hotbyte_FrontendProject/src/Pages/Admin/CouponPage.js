import React from 'react';
import AdminLayout from '../../Components/Admin/AdminLayout';
import CouponManagement from '../../Components/Admin/CouponManagement';



export default function CouponPage() {
  return (
    <AdminLayout>
      <CouponManagement/>
    </AdminLayout>
  );
}
