import React from 'react';
import RestaurantLayout from '../../Components/Restaurant/RestaurantLayout';
import RestaurantDashboard from '../../Components/Restaurant/RestaurantDashboard';



export default function RestaurantDashboardPage() {
  return (
    <RestaurantLayout>
        <RestaurantDashboard/>
    </RestaurantLayout>
     
  );
}
