import React from 'react';
import RestaurantLayout from '../../Components/Restaurant/RestaurantLayout';
import RestaurantProfileSettings from '../../Components/Restaurant/RestaurantProfileSettings';



export default function RestaurantProfileManagementPage() {
  return (
    <RestaurantLayout>
        <RestaurantProfileSettings/>
    </RestaurantLayout>
     
  );
}
