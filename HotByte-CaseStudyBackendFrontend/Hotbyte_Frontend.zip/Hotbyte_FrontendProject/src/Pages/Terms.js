import CustomMenubar from "../Components/CustomMenubar";
import Footer from "../Components/Footer";
import TermsUser from "../Components/TermsUser"; 

const Terms= () => {
    return (<>
    <CustomMenubar/>
    <TermsUser />
    <Footer/>
    </>
    );
}
export default Terms;