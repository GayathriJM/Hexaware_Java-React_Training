import React from 'react';
import AboutUser from '../Components/AboutUser'; 
import CustomMenubar from '../Components/CustomMenubar';
const About = () => {
    return (
        <>
        <CustomMenubar/>
        <AboutUser />
        </>
    );
}
export default About;