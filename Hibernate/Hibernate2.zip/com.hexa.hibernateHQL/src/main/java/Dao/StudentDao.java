package Dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.query.Query;

import com.mysql.cj.x.protobuf.MysqlxCrud.Update;

import Connection.StudentConn;
import Model.Student;

public class StudentDao implements DaoStudentI {
	
	SessionFactory factory;
	
	public StudentDao(){
		factory = StudentConn.getSessionFactory();
	}
	
	@Override
	public void saveData(Student s) {	
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		session.save(s);
		txt.commit();
		
	}

	@Override
	public void removeByRoll(int rno) {
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		Student  s = session.find(Student.class, rno);
		if(s==null) {
			System.out.println("not found");
		}else {
			session.delete(s);
			txt.commit();
		}
		
		
	}

	@Override
	public void updateData(Student s) {
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		 Student ss = session.find(Student.class, s.getRollno());
		    if (ss == null) {
		        System.out.println("not found");
		    } else {
		        ss.setName(s.getName());
		        ss.setMarks(s.getMarks());
		        txt.commit();
		    }
		
	}

	@Override
	public Student searchByRoll(int rno) {
		 Session session = factory.openSession();
		    Student s = session.find(Student.class, rno);
		    if (s == null) {
		        System.out.println("not found");
		    }
		    return s;
		
	}

	@Override
	public void showData() {
		Session session = factory.openSession();
		Query<Student> query = session.createQuery("from Student");
		query.setFirstResult(0);
		query.setMaxResults(5);
		List<Student> students = query.list();
		for(Student s : students) {
			System.out.println(s.toString());
		}
		
		
	}

	@Override
	public void searchHQLName(String name) {
	
		Session session=factory.openSession();	
		Query <Student>Q=session.createQuery("from Student where name=:name",Student.class);
		Q.setParameter("name", name);
		 List<Student> usersList=  Q.list();	
		 for(Student  u : usersList )
		 {
			 System.out.println(u.toString());
		 }
	
	}
	
	@Override
	public void searchHQLNameMarks(String name, double marks) {
	
		Session session=factory.openSession();	
		Query <Student>Q=session.createQuery("from Student where name=:name and marks=:marks",Student.class);
		Q.setParameter("name", name);
		Q.setParameter("marks", marks);
		 List<Student> usersList=  Q.list();	
		 for(Student  u : usersList )
		 {
			 System.out.println(u.toString());
		 }
	
	}

	@Override
	public void searchByMarks(double marks) {
		Session session = factory.openSession();
		Query<Student>q = session.createQuery("from Student where marks >: marks",Student.class);
		q.setParameter("marks", marks);
		List<Student>qlist = q.list();
		
		qlist.stream().forEach((i)->System.out.println(i.toString()));
		
	}
	
	public void removeByRollNo(int rollno) {
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		Query <Student>Q=session.createQuery("delete Student where rollno=:rollno");
		Q.setParameter("rollno", rollno);
		int r=Q.executeUpdate();
		if(r>0) {
			System.out.println("removed");
		}else {
			System.out.println("not found");
			
		}
		txt.commit();
	}

	public void updateNameByRoll(int roll, String newName) {
	    Session session = factory.openSession();
	    Transaction tx = session.beginTransaction();
	    Query q = session.createQuery("update Student set name = :name where rollno = :roll");
	    q.setParameter("name", newName);
	    q.setParameter("roll", roll);
	    int up = q.executeUpdate();
	    if (up > 0) {
	        System.out.println("updated");
	    } else {
	        System.out.println("not found");
	    }
	    tx.commit();
	}
	

	

}
