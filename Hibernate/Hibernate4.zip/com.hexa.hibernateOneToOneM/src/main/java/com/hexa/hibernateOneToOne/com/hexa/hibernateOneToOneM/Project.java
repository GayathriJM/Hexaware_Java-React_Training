package com.hexa.hibernateOneToOne.com.hexa.hibernateOneToOneM;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Project {

    @Id
    int proId;
    String proName;
    Double budget;

    Project() {}

	public Project(int proId, String proName, Double budget) {
		super();
		this.proId = proId;
		this.proName = proName;
		this.budget = budget;
	}

	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public Double getBudget() {
		return budget;
	}

	public void setBudget(Double budget) {
		this.budget = budget;
	}

	@Override
	public String toString() {
		return "Project [proId=" + proId + ", proName=" + proName + ", budget=" + budget + "]";
	}
    
    
    
}