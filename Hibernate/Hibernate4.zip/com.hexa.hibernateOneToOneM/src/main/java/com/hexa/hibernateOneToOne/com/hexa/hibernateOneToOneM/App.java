package com.hexa.hibernateOneToOne.com.hexa.hibernateOneToOneM;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.StyledEditorKit.ForegroundAction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class App 
{
    public static void main( String[] args )
    {
//    	  SessionFactory sessionFactory= new Configuration().
//    			   configure("hiber.config.xml").
//    			   addAnnotatedClass(Student.class).
//    			   addAnnotatedClass(Address.class).
//    			   buildSessionFactory();
//    	  
//    	  Session session = sessionFactory.openSession();
//    	  Transaction txt = session.beginTransaction();
//    	  
//    	  Address a1 = new Address();
//    	  a1.setAddressid(2);
//    	  a1.setCity("chennai");
//    	  session.save(a1); - no need bcoz we used cascade
//    	  
//    	  Student s1=new Student();
//    	  s1.setRollno(102);
//    	  s1.setName("divya");
//    	  s1.setAddress(a1);
//    	 
//    	  session.save(s1);
//    	  txt.commit();
    	
    	
//    	SessionFactory sessionFactory= new Configuration().
// 			   configure("hiber.config.xml").
// 			   addAnnotatedClass(Employee.class).
// 			   addAnnotatedClass(Laptop.class).
// 			   buildSessionFactory();
//    	
//    	 Session session = sessionFactory.openSession();
//   	  	Transaction txt = session.beginTransaction();
//   	  	
//   	 Laptop l = new Laptop();
//     l.setLaptopId(101);
//     l.setBrand("Asus");
//     session.save(l);
//
//     Employee emp = new Employee();
//     emp.setEmpId(1);
//     emp.setEmpName("gayathri");
//     emp.setSalary(50000.00);
//     emp.setLaptop(l);
//
//     session.save(emp);
//     txt.commit();
    	
    	
    	
//    	SessionFactory sessionFactory= new Configuration().
// 			   configure("hiber.config.xml").
// 			   addAnnotatedClass(Employee.class).
// 			   addAnnotatedClass(Department.class).
// 			   buildSessionFactory();
// 	  
// 	  Session session = sessionFactory.openSession();
// 	  Transaction txt = session.beginTransaction();
// 	  
// 	  Employee e1 = new Employee(102,"asha",3000.0);
// 	 Employee e2 = new Employee(103,"jay",7000.0);
// 	 
// 	 List<Employee> list = new ArrayList();
// 	 list.add(e1);
// 	list.add(e2);
// 	
// 	Department objD = new Department();
// 	objD.setdCode(1);
// 	objD.setdName("Admin");
// 	objD.setEmpList(list);
// 	
// 	session.save(objD);
// 	txt.commit();
    	
    	
//    	SessionFactory sessionFactory = new Configuration()
//                .configure("hiber.config.xml")
//                .addAnnotatedClass(Company.class)
//                .addAnnotatedClass(Project.class)
//                .buildSessionFactory();
//
//        Session session = sessionFactory.openSession();
//        Transaction txt = session.beginTransaction();
//
//        Project p1 = new Project(201, "ai", 50000.0);
//        Project p2 = new Project(202, "Web", 30000.0);
//
//        List<Project> pro = new ArrayList();
//        pro.add(p1);
//        pro.add(p2);
//
//        Company com = new Company();
//        com.setComId(1);
//        com.setComName("hexaware");
//        com.setProjectList(pro);
//
//        session.save(com);
//        txt.commit();
 	
 	 
    	
//    	SessionFactory sessionFactory= new Configuration().
//  			   configure("hiber.config.xml").
//  			   addAnnotatedClass(Employee.class).
//  			   addAnnotatedClass(Department.class).
//  			   buildSessionFactory();
//  	  
//  	  Session session = sessionFactory.openSession();
//
//  	  Department d = session.get(Department.class, 1);
//  	  System.out.print(d.getdName()); 
//  	  System.out.print(d.getEmpList()); 
 	  
    	
    }
}
