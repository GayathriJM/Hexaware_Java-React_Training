package com.hexa.hibernateOneToOne.com.hexa.hibernateOneToOneM;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Company {

    @Id
    int comId;
    String comName;

    @OneToMany(targetEntity = Project.class, cascade = CascadeType.ALL)
    List<Project> projectList;

    Company() {}

	public Company(int comId, String comName, List<Project> projectList) {
		super();
		this.comId = comId;
		this.comName = comName;
		this.projectList = projectList;
	}

	public int getComId() {
		return comId;
	}

	public void setComId(int comId) {
		this.comId = comId;
	}

	public String getComName() {
		return comName;
	}

	public void setComName(String comName) {
		this.comName = comName;
	}

	public List<Project> getProjectList() {
		return projectList;
	}

	public void setProjectList(List<Project> projectList) {
		this.projectList = projectList;
	}

	@Override
	public String toString() {
		return "Company [comId=" + comId + ", comName=" + comName + ", projectList=" + projectList + "]";
	}
    
    
}
