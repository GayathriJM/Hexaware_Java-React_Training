package com.hexa.hibernateOneToOne.com.hexa.hibernateOneToOneM;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class LaptopEx {
    @Id
    int laptopId;
    String brand;
    
    LaptopEx(){}

	public LaptopEx(int laptopId, String brand) {
		super();
		this.laptopId = laptopId;
		this.brand = brand;
	}

	public int getLaptopId() {
		return laptopId;
	}

	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Laptop [laptopId=" + laptopId + ", brand=" + brand + "]";
	}
    
    
}
