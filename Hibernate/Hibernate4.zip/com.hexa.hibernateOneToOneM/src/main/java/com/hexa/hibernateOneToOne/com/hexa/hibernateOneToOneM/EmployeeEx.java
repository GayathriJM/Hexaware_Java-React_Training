package com.hexa.hibernateOneToOne.com.hexa.hibernateOneToOneM;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class EmployeeEx {
    @Id
    int empId;
    String empName;
    double salary;

    @OneToOne
    LaptopEx laptop;
    
    EmployeeEx(){}

	public EmployeeEx(int empId, String empName, double salary, LaptopEx laptop) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.laptop = laptop;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public LaptopEx getLaptop() {
		return laptop;
	}

	public void setLaptop(LaptopEx laptop) {
		this.laptop = laptop;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", laptop=" + laptop + "]";
	}
    
    
}
