package com.hexa.hibernateMVC.com.hexa.hibernateMVC1;

import Service.StudentService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	StudentService service = new StudentService() ;
//    	service.saveService();
//    	service.removeData();
//    	service.updateService();
//    	service.searchService();
//    	service.showAll();
    	service.searchByNameService();

    	
        System.out.println( "Hello World!" );
    }
}
