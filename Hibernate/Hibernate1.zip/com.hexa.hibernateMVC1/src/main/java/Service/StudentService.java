package Service;

import java.util.List;
import java.util.Scanner;

import Dao.StudentDao;
import Model.Student;

public class StudentService { // take data from user take give it to dao layer(Acts as intermediary between user input and DAO operations)
	
	Student s;  // Student entity object
	StudentDao dao; // Data Access Object
	
	Scanner sc; // For user input
	
	public StudentService() {
		//Initializes dependencies -Creates its own DAO instance
		s= new Student();
		sc=new Scanner(System.in);
		dao= new StudentDao();
	}
	
	public void saveService() {
		System.out.print("enter rollno:");
		s.setRollno(sc.nextInt());
		
		System.out.print("enter name:");
		sc.nextLine();
		s.setName(sc.nextLine());
		
		System.out.print("enter marks:");
		s.setMarks(sc.nextDouble());
		
		dao.saveData(s);
		
	}
	
	public void removeData() {
		
		int rno;
		System.out.print("enter rollno:");
		rno = sc.nextInt();
		dao.removeByRoll(rno);

}
	public void updateService() {
	    System.out.print("enter rollno:");
	    int rn = sc.nextInt();
	    sc.nextLine();
	    System.out.print("enter name:");
	    String name = sc.nextLine();
	    System.out.print("enter marks:");
	    double marks = sc.nextDouble();
	    Student s = new Student(rn, name, marks);
	    dao.updateData(s);
	}
	
	public void searchService() {
	    System.out.print("enter rollno:");
	    int rno = sc.nextInt();
	    Student s = dao.searchByRoll(rno);
	    if (s != null) {
	        System.out.println(s);
	    }
	}
	
	public void showAll() {
		dao.showData();
	}
	
	public void searchByNameService() {
	    System.out.print("enter name: ");
	    sc.nextLine();
	    String name = sc.nextLine();
	    List<Student> mat = dao.searchByName(name);
	    if (!mat.isEmpty()) {
	        for (Student s : mat) {
	            System.out.println(s);
	        }
	    } else {
	        System.out.println("not found");
	    }
	}



	
}
