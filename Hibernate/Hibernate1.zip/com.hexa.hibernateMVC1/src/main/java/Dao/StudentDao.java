package Dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.query.Query;

import Connection.StudentConn;
import Model.Student;

public class StudentDao implements DaoStudentI {
	
	SessionFactory factory;
	
	public StudentDao(){
		factory = StudentConn.getSessionFactory();
	}
	
	@Override
	public void saveData(Student s) {	
		
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		session.save(s);
		txt.commit();
		
	}

	@Override
	public void removeByRoll(int rno) {
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		Student  s = session.find(Student.class, rno);
		if(s==null) {
			System.out.println("not found");
		}else {
			session.delete(s);
			txt.commit();
		}
		
		
	}

	@Override
	public void updateData(Student s) {
		Session session = factory.openSession();
		Transaction txt = session.beginTransaction();
		 Student ss = session.find(Student.class, s.getRollno());
		    if (ss == null) {
		        System.out.println("not found");
		    } else {
		        ss.setName(s.getName());
		        ss.setMarks(s.getMarks());
		        txt.commit();
		    }
		
	}

	@Override
	public Student searchByRoll(int rno) {
		 Session session = factory.openSession();
		    Student s = session.find(Student.class, rno);
		    if (s == null) {
		        System.out.println("not found");
		    }
		    return s;
		
	}

	@Override
	public void showData() {
		Session session = factory.openSession();
		Query<Student> query = session.createQuery("from Student");
		List<Student> students = query.list();
		for(Student s : students) {
			System.out.println(s.toString());
		}
		
		
	}

	@Override
	public List<Student> searchByName(String name) {
	    Session session = factory.openSession();
	    Query<Student> query = session.createQuery("from Student", Student.class);
	    List<Student> students = query.list();
	    List<Student> ms = new ArrayList<>();
	    for (Student s : students) {
	        if (s.getName().toLowerCase().contains(name.toLowerCase())) {
	            ms.add(s);
	        }
	    }
	    return ms;
	}

}
