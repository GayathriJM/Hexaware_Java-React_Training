package Dao;

import java.util.List;

import Model.Student;

public interface DaoStudentI {
	
	void saveData(Student s);
	void removeByRoll(int rno);
	void updateData(Student s);
	Student searchByRoll(int rno);
	void showData();
	List<Student> searchByName(String name);




}
