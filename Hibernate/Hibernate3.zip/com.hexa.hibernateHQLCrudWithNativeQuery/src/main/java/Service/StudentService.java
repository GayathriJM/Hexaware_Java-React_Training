package Service;

import java.util.List;
import java.util.Scanner;

import Dao.StudentDao;
import Model.Student;

public class StudentService { // take data from user take give it to dao layer
	
	Student s;
	StudentDao dao;
	
	Scanner sc;
	
	public StudentService() {
		
		s= new Student();
		sc=new Scanner(System.in);
		dao= new StudentDao();
	}
	
	public void saveService() {
		System.out.print("enter rollno:");
		s.setRollno(sc.nextInt());
		
		System.out.print("enter name:");
		sc.nextLine();
		s.setName(sc.nextLine());
		
		System.out.print("enter marks:");
		s.setMarks(sc.nextDouble());
		
		dao.saveData(s);
		
	}
	
	public void removeData() {
		
		int rno;
		System.out.print("enter rollno:");
		rno = sc.nextInt();
		dao.removeByRoll(rno);

}
	public void updateService() {
	    System.out.print("enter rollno:");
	    int rn = sc.nextInt();
	    sc.nextLine();
	    System.out.print("enter name:");
	    String name = sc.nextLine();
	    System.out.print("enter marks:");
	    double marks = sc.nextDouble();
	    Student s = new Student(rn, name, marks);
	    dao.updateData(s);
	}
	
	public void searchService() {
	    System.out.print("enter rollno:");
	    int rno = sc.nextInt();
	    Student s = dao.searchByRoll(rno);
	    if (s != null) {
	        System.out.println(s);
	    }
	}
	
	public void showAll() {
		dao.showData();
	}
	
	
	public void searchByName() {
		System.out.println("enter search name:");
		String snm = sc.nextLine();
		dao.searchHQLName(snm);
	}

	
	public void searchByNameMarks() {
		System.out.println("enter search name:");
		String snm = sc.nextLine();
		System.out.println("enter search marks:");
		double marks = sc.nextDouble();
		dao.searchHQLNameMarks(snm, marks);
	}

	public void filterByMarks() {
	    System.out.print("Enter marks: ");
	    double ma = sc.nextDouble();
	    dao.searchByMarks(ma);
	}
	
	
	public void removeByRollHQL() {
		System.out.print("Enter roll: ");
	    int rollno = sc.nextInt();
	    dao.removeByRollNo(rollno);
	}
	
	 public void updateNameByRollService() {
	        System.out.print("enter roll:");
	        int roll = sc.nextInt();
	        sc.nextLine();
	        System.out.print("enter name:");
	        String nn = sc.nextLine();
	        dao.updateNameByRoll(roll, nn);
	 }

	
}
