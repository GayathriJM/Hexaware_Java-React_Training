package com.hexa.hibernateHQL.com.hexa.hibernateHQL2;

import Service.StudentService;

public class App 
{
    public static void main( String[] args )
    {
    	
    	StudentService service = new StudentService() ;
//    	service.saveService();
//    	service.removeData();
//    	service.updateService();
//    	service.searchService();
//    	service.showAll();
    	service.searchByName();
//    	service.searchByNameMarks();
//    	service.filterByMarks();
//    	service.removeByRollHQL();
//    	service.updateNameByRollService();
    	

    	
        System.out.println( "Hello World!" );
    }
}
