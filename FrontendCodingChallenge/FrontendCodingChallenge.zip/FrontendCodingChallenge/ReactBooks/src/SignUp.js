import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { Form, Button, Container, Header, Message, Dropdown } from 'semantic-ui-react';

const SignUp=()=> {
  const [registerData, setRegisterData] = useState({
    username: '', password: '', role: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const navigate = useNavigate();

 const handleChange = (e, { name, value }) => {
    setRegisterData({ ...registerData, [name]: value });
  };

   const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      await axios.post('http://localhost:9006/api/auth/register', registerData);
      setSuccess('Registered successfully');
       setTimeout(() => navigate('/'), 1500); 
    } catch (err) {
      setError('Registration failed. Try again');
    }
  };

   const roleOptions = [
    { key: 'user', text: 'USER', value: 'USER' },
    { key: 'admin', text: 'ADMIN', value: 'ADMIN' }
  ];

  return (
     <Container text style={{ marginTop: '50px' }}>
      <Header as="h2" textAlign="center">Sign Up</Header>
      {error && <Message negative>{error}</Message>}
      {success && <Message positive>{success}</Message>}
      <Form onSubmit={handleRegister}>
        <Form.Input label="Username" placeholder="Username" name="username" value={registerData.username} onChange={handleChange} required />
        <Form.Input label="Password" type="password" placeholder="Password" name="password" value={registerData.password} onChange={handleChange} required />
        <Form.Select label="Role" name="role" options={roleOptions} placeholder="Select Role" value={registerData.role} onChange={handleChange} required />
        <Button primary type="submit">Register</Button>
        <Message> Already have an account? <Link to="/">Login</Link></Message>
      </Form>
    </Container>
  );
}
export default SignUp;