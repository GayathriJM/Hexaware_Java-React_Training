import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Header,
  Form,
  Button,
  Table,
  Message,
  Segment,
} from 'semantic-ui-react';


const Books=()=> {
  const [books, setBooks] = useState([]);
  const [form, setForm] = useState({
    isbn: '',
    title: '',
    author: '',
    publicationYear: ''
  });
  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [searchIsbn, setSearchIsbn] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:9006/books', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBooks(res.data);
    } catch (err) {
      console.error('Fetch books error:', err);
      setError('Session expired. Please login again');
      navigate('/');
    }
  };

  const handleChange = (e, { name, value }) => {
    setForm({ ...form, [name]: value });
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    const token = localStorage.getItem('token');
    try {
      await axios.post('http://localhost:9006/books', {
        ...form,
        publicationYear: parseInt(form.publicationYear),
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchBooks();
      setForm({ isbn: '', title: '', author: '', publicationYear: '' });
      setIsEditing(false); 
      setSuccess('Book added successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Add book error:', err);
      setError('Failed to add book');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
     setError('');
     setSuccess('');
    const token = localStorage.getItem('token');
    try {
      await axios.put(`http://localhost:9006/books/${form.isbn}`, {
        ...form,
        publicationYear: parseInt(form.publicationYear),
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSuccess('Book updated successfully');
      setTimeout(() => setSuccess(''), 3000);
      fetchBooks();
      setForm({ isbn: '', title: '', author: '', publicationYear: '' });
      setIsEditing(false); 
    } catch (err) {
      console.error('Update book error:', err);
      setError('Failed to update book');
      setTimeout(() => setSuccess(''), 3000);
    }
  };

 const handleEdit = (book) => {
  setForm(book);
  setIsEditing(true);
};

  const handleDelete = async (isbn) => {
    const token = localStorage.getItem('token');
    try {
      await axios.delete(`http://localhost:9006/books/${isbn}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSuccess('Book deleted successfully');
      fetchBooks();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Delete book error:', err);
      setError('Failed to delete book');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleSearch = async () => {
  if (!searchIsbn.trim()) return;

  const token = localStorage.getItem('token');
  try {
    const res = await axios.get(`http://localhost:9006/books/${searchIsbn}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setBooks([res.data]); // Show only the matched book
  } catch (err) {
    console.error('Search error:', err);
    setError('Book not found');
    setTimeout(() => setError(''), 3000);
  }
};

const handleResetSearch = () => {
  setSearchIsbn('');
  fetchBooks();
};



  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
   <Container style={{ marginTop: '50px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Header as="h2">Book Management</Header>
        <Button color="red" onClick={handleLogout}>Logout</Button>
      </div>
      {error && <Message negative>{error}</Message>}
      {success && <Message positive>{success}</Message>}
       <Segment>
        <Form>
          <Form.Group widths="equal">
            <Form.Input label="ISBN" name="isbn" placeholder="ISBN" value={form.isbn} onChange={handleChange} required />
            <Form.Input label="Title" name="title" placeholder="Title" value={form.title} onChange={handleChange} required />
            <Form.Input label="Author" name="author" placeholder="Author" value={form.author} onChange={handleChange} required />
            <Form.Input label="Year" name="publicationYear" type="number" placeholder="Year" value={form.publicationYear} onChange={handleChange} required />
            <Form.Input label="Search by ISBN" placeholder="Enter ISBN" value={searchIsbn} onChange={(e) => setSearchIsbn(e.target.value)} />
          </Form.Group>
          <Button primary onClick={handleAdd} disabled={isEditing}  style={{ marginRight: '10px', width: 'auto' }}>
            Add Book
          </Button>
          <Button color="teal" onClick={handleUpdate} disabled={!isEditing} style={{ width: 'auto' }}>
            Update Book
          </Button>
           <Button primary onClick={handleSearch}>Search</Button>
          <Button onClick={handleResetSearch}>Reset</Button>
          {isEditing && (
          <Button color="grey" onClick={() => {
            setForm({ isbn: '', title: '', author: '', publicationYear: '' });
            setIsEditing(false);
          }} style={{ marginLeft: '10px', width: 'auto' }}>
            Cancel
          </Button>
          
          )}

        </Form>
      </Segment>

      <Table celled striped>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>ISBN</Table.HeaderCell>
            <Table.HeaderCell>Title</Table.HeaderCell>
            <Table.HeaderCell>Author</Table.HeaderCell>
            <Table.HeaderCell>Year</Table.HeaderCell>
            <Table.HeaderCell>Actions</Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {books.map((book) => (
            <Table.Row key={book.isbn}>
              <Table.Cell>{book.isbn}</Table.Cell>
              <Table.Cell>{book.title}</Table.Cell>
              <Table.Cell>{book.author}</Table.Cell>
              <Table.Cell>{book.publicationYear}</Table.Cell>
              <Table.Cell>
                <Button size="small" color="blue" onClick={() => handleEdit(book)}>
                  Edit
                </Button>{' '}
                <Button size="small" color="red" onClick={() => handleDelete(book.isbn)}>
                  Delete
                </Button>
              </Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table>
    </Container>
  );
}

export default Books;
