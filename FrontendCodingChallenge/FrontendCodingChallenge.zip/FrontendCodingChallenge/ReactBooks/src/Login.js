import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { Form, Button, Container, Header, Message } from 'semantic-ui-react';

const Login=()=> {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:9006/api/auth/login', { username, password });
      localStorage.setItem('token', res.data.token);
      navigate('/books');
    } catch (err) {
      setError('Invalid credentials');
    }
  };

  return (
     <Container text style={{ marginTop: '50px' }}>
      <Header as="h2" textAlign="center">Login</Header>
       {error && <Message negative>{error}</Message>}
      <Form onSubmit={handleLogin}>
         <Form.Input label="Username" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} required />
        <Form.Input label="Password" type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
        <Button primary type="submit">Login</Button>
         <Message>
          Don't have an account? <Link to="/signup">Sign Up</Link>
        </Message>
      </Form>
    </Container>
  );
}

export default Login;
