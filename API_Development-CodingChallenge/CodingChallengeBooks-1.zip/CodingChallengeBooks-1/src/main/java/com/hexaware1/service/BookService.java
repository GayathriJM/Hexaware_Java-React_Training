package com.hexaware1.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware1.dto.BookDTO;
import com.hexaware1.exception.BookNotFoundException;
import com.hexaware1.model.Book;
import com.hexaware1.repository.BookRepository;

@Service
public class BookService {
	
	 @Autowired
	    private BookRepository repo;
	 
	 @Autowired
	    private ModelMapper modelMap;

	 public Book dtoToBook(BookDTO dto) {
		 return modelMap.map(dto, Book.class);
	 }
	 
	 public BookDTO bookToDto(Book book) {
		 return modelMap.map(book, BookDTO.class);
	 }
	 
	 public BookDTO saveBook(BookDTO dto) {
	        Book b = dtoToBook(dto);
	        Book saved = repo.save(b);
	        return bookToDto(saved);
	    }
	 
	 public List<BookDTO> getAllBooks() {
		    List<Book> list = repo.findAll();
		    List<BookDTO> dtolist = new ArrayList<>();
		    for (Book bk : list) {
		        dtolist.add(bookToDto(bk));
		    }
		    return dtolist;
	 }
	 
	 public BookDTO getBookByIsbn(String isbn) {
	        Book bk = repo.findById(isbn)
	                .orElseThrow(() -> new BookNotFoundException("not found"));
	        return bookToDto(bk);
	    }

	 
	 public BookDTO updateBook(String isbn, BookDTO dto) {
	        Book bk = repo.findById(isbn)
	                .orElseThrow(() -> new BookNotFoundException("cannot update, book not found"));
	        bk.setTitle(dto.getTitle());
	        bk.setAuthor(dto.getAuthor());
	        bk.setPublicationYear(dto.getPublicationYear());
	        Book up = repo.save(bk);
	        return bookToDto(up);
	    }

	 public String deleteBook(String isbn) {
	        Book bk = repo.findById(isbn)
	                .orElseThrow(() -> new BookNotFoundException("cannot delete, book not found"));
	        repo.deleteById(isbn);
	        return "deleted: " + isbn;
	    }

}


