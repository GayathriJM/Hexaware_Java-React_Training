package com.hexaware1.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class Book {
	
	@Id
	@NotNull(message = "isbn is required")
	@Pattern(regexp = "^[0-9]{6}$", message = "isbn must be 6 digits")
	String isbn;
	
	@NotNull(message = "title is required")
	@Size(min = 3, max = 100)
	String title;
	
	@NotNull(message = "author is required")
    @Size(min = 2, max = 100)
	String author;
	
	@NotNull(message = "publication year is required")
	int publicationYear;
	
	Book(){
		
	}

	public Book(
			@NotNull(message = "isbn is required") @Pattern(regexp = "^[0-9]{6}$", message = "isbn must be 6 digits") String isbn,
			@NotNull(message = "title is required") @Size(min = 3, max = 100) String title,
			@NotNull(message = "author is required") @Size(min = 2, max = 100) String author,
			@NotNull(message = "publication year is required") int publicationYear) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.publicationYear = publicationYear;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(int publicationYear) {
		this.publicationYear = publicationYear;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", author=" + author + ", publicationYear=" + publicationYear
				+ "]";
	}
	
	
	
	

}

