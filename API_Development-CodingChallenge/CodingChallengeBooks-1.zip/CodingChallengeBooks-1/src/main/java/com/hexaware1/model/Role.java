package com.hexaware1.model;

public enum Role {
ADMIN,
USER
}
