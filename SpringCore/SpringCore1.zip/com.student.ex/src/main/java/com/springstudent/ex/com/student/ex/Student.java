package com.springstudent.ex.com.student.ex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {
	
	 @Autowired
	 @Qualifier("home")
	 Address a1;
	 
	 Student(){}

	public Student(Address a1) {
		super();
		this.a1 = a1;
	}

	public Address getA1() {
		return a1;
	}

	public void setA1(Address a1) {
		this.a1 = a1;
	}

	@Override
	public String toString() {
		return "Student [a1=" + a1 + "]";
	}
	
	 
}
