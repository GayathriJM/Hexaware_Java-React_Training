package com.springemployee.ex.com.employee.example;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

public class AppConfig {
	
	@Bean
    public Project pro() {
		Project pr = new Project();
		pr.setPid(102);
		pr.setDuration("5 months");
		pr.setCost(30000);
        return pr;
    }

    @Bean
    public Employee emp() {
    	Employee em = new Employee();
    	em.setEmpid(2);
    	em.setName("Divya");
    	em.setSalary(60000);
        
        Map<String, String> add = new HashMap<>();
        add.put("home", "Chennai");
        add.put("office", "Bangalore");
        em.setAddress(add);
        em.setProject(pro());
        return em;
    }

}
