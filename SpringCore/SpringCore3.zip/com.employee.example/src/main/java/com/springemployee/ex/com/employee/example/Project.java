package com.springemployee.ex.com.employee.example;

public class Project {

	int pid;
    String duration;
    double cost;
    
    Project() {}

	public Project(int pid, String duration, double cost) {
		super();
		this.pid = pid;
		this.duration = duration;
		this.cost = cost;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Project [pid=" + pid + ", duration=" + duration + ", cost=" + cost + "]";
	}
    
    
    
}
