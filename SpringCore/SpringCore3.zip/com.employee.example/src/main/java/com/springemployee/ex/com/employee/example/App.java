package com.springemployee.ex.com.employee.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App
{
    public static void main( String[] args )
    {
    	AbstractApplicationContext con = new ClassPathXmlApplicationContext("emp.xml");
    	Employee e = (Employee) con.getBean("em");
        System.out.println(e.toString());
        con.registerShutdownHook();

        AbstractApplicationContext cont = new AnnotationConfigApplicationContext(AppConfig.class);
    	Employee e1 = cont.getBean(Employee.class);
        System.out.println(e1.toString());
        cont.registerShutdownHook();
    }
}
