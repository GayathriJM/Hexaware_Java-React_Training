package com.springemployee.ex.com.employee.example;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import java.util.Map;

public class Employee implements InitializingBean, DisposableBean{

	 int empid;
	 String name;
	 double salary;
	 Map<String, String> address;
	 Project project;
	 
	 Employee() {}

	public Employee(int empid, String name, double salary, Map<String, String> address, Project project) {
		super();
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		this.address = address;
		this.project = project;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Map<String, String> getAddress() {
		return address;
	}

	public void setAddress(Map<String, String> address) {
		this.address = address;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + ", address=" + address
				+ ", project=" + project + "]";
	}
	 
	@PostConstruct
    public void init() {
        System.out.println("Starting");
    }

    @PreDestroy
    public void clean() {
        System.out.println("Ending");
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("initialized");
    }

    @Override
    public void destroy() throws Exception {
        System.out.println("destroyed");
    }
		
	}
	    

