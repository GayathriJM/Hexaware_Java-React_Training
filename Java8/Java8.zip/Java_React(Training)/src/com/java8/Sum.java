package com.java8;

public class Sum  implements calculator{
 
	public int  cal(int a, int b)
	{
		
		return a+b;
		
	}
}