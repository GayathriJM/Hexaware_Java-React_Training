package com.java8_2;

public interface Sim {
    void calling();
    void message();
}