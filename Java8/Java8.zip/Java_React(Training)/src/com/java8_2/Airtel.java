package com.java8_2;

public class Airtel implements Sim {
    public void calling() {
        System.out.println("1rs for 1 call");
    }

    public void message() {
        System.out.println("we are adding new....message 1rs");
    }
}