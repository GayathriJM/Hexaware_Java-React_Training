package com.java8_3;

@FunctionalInterface
public interface Payment {
    int calBill(int amt);
}
