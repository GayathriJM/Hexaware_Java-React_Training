package com.example.demo.Service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Item;
import com.example.demo.JpaRepo.ItemRepo;

@Service
public class ItemService {
	
	@Autowired
	ItemRepo repo;
	
	public Item addItem(Item item) {
        return repo.save(item);
    }
	
	public Item getItemByCode(String code) {
        return repo.findById(code).orElse(null);
    }
	
	public Item updatePrice(String code, BigDecimal price) {
        Item i = repo.findById(code).orElse(null);
        if (i != null) {
            i.setPrice(price);
            repo.save(i);
        }
        return i;
    }
	
	public String generateBill(String code, int qty) {
	    Item item = repo.findById(code).orElse(null);
	    if (item == null) {
	        return "not found " + code;
	    }
	    if(item.getQuantity() < qty) {
	    	return "insufficient";
	    }
	    item.setQuantity(item.getQuantity()- qty);
	    BigDecimal tot = item.getPrice().multiply(new BigDecimal(qty));
	    repo.save(item);
	    return "total price: " + tot;
	}


}
