package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Customer;
import com.example.demo.JpaRepo.CustomerRepo;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepo repo;
	
	public Customer dsaveD(Customer c) {
		
		Customer c1 = repo.save(c);
		return c1;
	}
	
	
	//by JPQL
	public List<Customer> getData1()
	{
		 List l = repo.findAllCustomer();
		 return l;
	}
	
//	public Customer getSearch(int ac) {
//		return repo.findById(ac).orElse(null);
//	}
	
	public Customer getSearch(int ac) {
		return repo.findByActJPQL(ac);
	}
	
	public Customer getByName1(String nm) {
	    return repo.findByNameJPQL(nm);
	}
	
	public int UpdateBal(int ac, double bal) {
		return repo.deposit1(ac, bal);
	}
	
	public String withdrawAc(int ac, double amt) {
		Customer c = repo.findById(ac).orElse(null);
	    if (c == null) {
	        return "not found";
	    }
	    if (c.getBalance() - amt < 1000) {
	        return "insufficient balance";
	    }
	    repo.withdraw(ac, amt);
	    double newBal = c.getBalance() - amt;
	    return "successful" + newBal;
	}
	
	public String deleteCustomer(int actno) {
	    Customer c = repo.findById(actno).orElse(null);
	    if (c == null) {
	        return "not found";
	    }
	    repo.deleteCustomerByAcctno(actno);
	    return "deleted";
	}

	
	
	public String deleteById(int ac) {
		 Customer c = repo.findById(ac).orElse(null);
		    if (c != null) {
		         repo.deleteById(ac);
		        return "found" + ac;
		    } else {
		        return "not found";
		    }
	}

	public String depositAmount(int ac,double amt) {
	    Customer c = repo.findById(ac).orElse(null);
	    if (c != null) {
	        c.setBalance(c.getBalance() + amt);
	        repo.save(c);
	        return "deposited " + c.getBalance();
	    } else {
	        return "not found";
	    }
	}
}
